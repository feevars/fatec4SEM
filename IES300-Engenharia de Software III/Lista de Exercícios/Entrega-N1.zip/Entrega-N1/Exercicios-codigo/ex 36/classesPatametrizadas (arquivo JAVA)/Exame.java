package classeParametrizada;

public class Exame {

	private int numero;
	private String descricao;
	private String resultado;
	
	public Exame (int numero, String descricao, String resultado) {
		this.numero = numero;
		this.descricao = descricao;
		this.resultado = resultado;
	}
	
}
