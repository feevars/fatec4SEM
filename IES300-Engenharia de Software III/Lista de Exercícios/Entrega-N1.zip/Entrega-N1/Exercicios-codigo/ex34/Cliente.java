package ex34;

import java.util.Set;

public class Cliente {

	private String nome;

	private String cpf;

	private String endereco;

	private String telefone;

	private Set<Pet> pets;

	public void create() {

	}

	public Set<Pet> getPets() {
		return null;
	}

}
