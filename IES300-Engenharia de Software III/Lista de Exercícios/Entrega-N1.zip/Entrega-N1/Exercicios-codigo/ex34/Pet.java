package ex34;

import java.util.List;

import entities.enums.Porte;
import entities.enums.Tipo;

public class Pet {

	private String nome;

	private Tipo tipo;

	private Porte porte;

	private List<String> historico;

	public void create() {

	}

}
