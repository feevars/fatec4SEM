package ex34;

public enum Tipo {

	CAO,

	GATO,

	AVE,

	REPTIL,

	ROEDOR;
}
