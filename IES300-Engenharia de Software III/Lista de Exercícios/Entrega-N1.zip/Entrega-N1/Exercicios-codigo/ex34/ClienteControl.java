package ex34;

import java.util.Set;

import entities.Cliente;
import entities.Pet;

public class ClienteControl {

	public void cadastrarCliente() {

	}

	public boolean cadastraNovoCliente(String nome, String cpf, String endereco, String telefone) {
		return false;
	}

	public Set<Pet> verificarListaPets(Cliente cliente) {
		return null;
	}

	public boolean buscarNomeCliente(String nome) {
		return false;
	}

	public boolean adicionarPet(Pet pet) {
		return false;
	}

}
