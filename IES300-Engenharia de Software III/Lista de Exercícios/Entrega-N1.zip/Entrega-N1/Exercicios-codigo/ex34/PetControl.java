package ex34;
import ex34.*;

public class PetControl {

	public boolean atualizarHistorico(String diagnostico) {
		return false;
	}

	public void cadastratNovoPet(String nome, Tipo tipo, Porte porte) {

	}

}
