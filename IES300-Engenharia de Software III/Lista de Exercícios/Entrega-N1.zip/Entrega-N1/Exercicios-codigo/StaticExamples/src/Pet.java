
public class Pet {

	static int contConsultas;
}
