
public class Veterinario {

	static String crmv;
}
