
public class SistemaDePagamento {

	public static void emitirBoleto() {
		System.out.println("boleto gerado com sucesso!");
	}
}
