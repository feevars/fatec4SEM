package boundaries;

import java.util.Set;

import entities.Pet;

public class MarcarConsultaView {

	public boolean verificarClienteExiste(String nome) {
		return false;
	}

	public Set<Pet> verificarPetsCliente(String nome) {
		return null;
	}

	public void consultarAgendaConsultorio() {

	}

	public boolean verificarVetExiste(String nome) {
		return false;
	}

	public boolean verificarDataDisponivel(int vet) {
		return false;
	}

	public void agendarConsulta() {

	}

}
