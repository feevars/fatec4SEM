package boundaries;

import java.util.Set;

import entities.Pet;
import entities.enums.Porte;
import entities.enums.Tipo;

public class CadastrarPetView {

	private void cadastratNovoPet(String nome, Tipo tipo, Porte porte) {

	}

	private Set<Pet> buscaNomeCliente() {
		return null;
	}

}
