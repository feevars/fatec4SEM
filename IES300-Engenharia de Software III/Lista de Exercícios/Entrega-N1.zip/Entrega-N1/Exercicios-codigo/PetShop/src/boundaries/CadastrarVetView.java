package boundaries;

public class CadastrarVetView {

	public boolean validarCrmv(String crmv) {
		return false;
	}

	private boolean buscarNomeVet(String nome) {
		return false;
	}

	public boolean cadastraNovoVet(String nome, String crmv, String endereco, String tel) {
		return false;
	}

	public boolean adicionarEspecializacoes(String nome) {
		return false;
	}

}
