package boundaries;

import java.util.Date;

import entities.Pet;
import entities.Veterinario;

public class AgendarExameView {

	private Pet pet;

	private Veterinario vet;

	public Date agendarExame(String titulo, String descricao, Veterinario solicitou) {
		return null;
	}

	public boolean verificarDataDisponivel(Date data) {
		return false;
	}

}
