package boundaries;

public class CadastrarClienteView {

	public boolean verificaClienteExiste(String nome) {
		return false;
	}

	public boolean cadastraNovoCliente(String nome, String Cpf, String endereco, String telefone) {
		return false;
	}

	public boolean verificaCpfValido(String cpf, String linkSerasa) {
		return false;
	}

}
