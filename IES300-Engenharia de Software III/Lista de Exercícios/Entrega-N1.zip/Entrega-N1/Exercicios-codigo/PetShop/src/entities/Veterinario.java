package entities;

import java.util.Date;

public class Veterinario {

	private String nome;

	private String crmv;

	private String endereco;

	private String tel;

	public void create() {

	}

	public boolean estaTrabalhando(Date data) {
		return false;
	}

}
