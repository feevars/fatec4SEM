package entities;

import java.util.Date;

public class AgendaConsultorio {

	public boolean agendarExame(Veterinario vet, Date data) {
		return false;
	}
}
