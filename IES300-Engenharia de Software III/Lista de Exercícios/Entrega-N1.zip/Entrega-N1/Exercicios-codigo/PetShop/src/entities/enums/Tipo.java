package entities.enums;

public enum Tipo {

	CAO,

	GATO,

	AVE,

	REPTIL,

	ROEDOR;
}
