package entities;

public class Pagamento {

	private int formaPag;

}
