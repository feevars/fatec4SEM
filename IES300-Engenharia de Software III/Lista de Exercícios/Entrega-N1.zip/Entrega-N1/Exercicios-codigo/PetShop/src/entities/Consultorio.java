package entities;

import java.util.Set;

public class Consultorio {

	private Set<Cliente> clientes;

	private Set<Veterinario> veterinarios;

	public Cliente buscarCliente(Set<Cliente> clientes) {
		return null;
	}

	public Set<Veterinario> getVets() {
		return null;
	}

}
