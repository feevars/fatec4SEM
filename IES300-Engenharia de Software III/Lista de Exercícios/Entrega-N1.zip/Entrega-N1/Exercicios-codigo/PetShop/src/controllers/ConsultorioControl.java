package controllers;

import java.util.Set;

import entities.Cliente;

public class ConsultorioControl {

	public Cliente buscarNomeCliente(String nome) {
		return null;
	}

	public boolean verificarVetExiste(String nome) {
		return false;
	}

	public boolean verificarClienteExiste(String nome) {
		return false;
	}

	public Set<Cliente> buscarCliente(String nome) {
		return null;
	}

}
