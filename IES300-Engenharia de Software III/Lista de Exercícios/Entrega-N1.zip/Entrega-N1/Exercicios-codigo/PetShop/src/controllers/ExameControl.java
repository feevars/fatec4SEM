package controllers;

import java.util.Date;

import entities.Pet;
import entities.Veterinario;

public class ExameControl extends ConsultaControl {

	private Date data;

	private Pet pet;

	private Veterinario quemSolicitou;

	private String resultado;

	private boolean foiRealizado;

	private Veterinario quemRealizou;

	public void criar() {

	}

}
