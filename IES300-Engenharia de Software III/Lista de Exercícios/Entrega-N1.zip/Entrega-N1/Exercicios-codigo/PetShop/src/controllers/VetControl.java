package controllers;

import java.util.Date;

public class VetControl {

	public boolean cadastraNovoVet(String nome, String crmv, String endereco, String tel) {
		return false;
	}

	public boolean estaTrabalhando(Date data) {
		return false;
	}

}
