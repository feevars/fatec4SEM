package controllers;

import entities.Cliente;

public class SistemaPagamentoControl {

	private int numConsultas;

	public int verificaConsultasCliente(Cliente cliente) {
		return 0;
	}

	public float verificaDescontoConsultas(int numConsultas) {
		return 0;
	}

}
