package controllers;

public class PetsClienteControl {

	private int attribute6;

}
