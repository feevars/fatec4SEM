package controllers;

import entities.Veterinario;
import java.util.Date;

public class AgendaConsultorioControl {

	public boolean agendarExame(Veterinario vet, Date data) {
		return false;
	}
}
