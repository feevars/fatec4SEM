package controllers;

import java.util.Date;

import entities.Veterinario;

public class AgendarExameControl {

	public Date agendarExame(String titulo, String descricao, Veterinario solicitou) {
		return null;
	}

}
