package controllers;

import entities.enums.Porte;
import entities.enums.Tipo;

public class PetControl {

	public boolean atualizarHistorico(String diagnostico) {
		return false;
	}

	public void cadastratNovoPet(String nome, Tipo tipo, Porte porte) {

	}

}
