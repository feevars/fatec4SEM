package controllers;

import entities.Cliente;
import entities.enums.Porte;
import entities.enums.Tipo;

public class CadastrarPetControl {

	public Cliente buscarNomeCliente(String nome) {
		return null;
	}

	public void cadastratNovoPet(String nome, Tipo tipo, Porte porte) {

	}

}
