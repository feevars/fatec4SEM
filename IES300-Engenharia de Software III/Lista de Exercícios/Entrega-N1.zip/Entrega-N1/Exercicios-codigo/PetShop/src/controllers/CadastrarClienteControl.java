package controllers;

import entities.Cliente;

public class CadastrarClienteControl {

	public boolean verificaClienteExiste(String nome) {
		return false;
	}

	public Cliente cadastraNovoCliente(String nome, String cpf, String endereço, String telefone) {
		return null;
	}

	public boolean verificaCpfValido(String cpf, String linkSerasa) {
		return false;
	}

}
