package controllers;

public class CadastrarVetControl {

	public boolean validarCrmv(String crmv) {
		return false;
	}

	public boolean buscarNomeVet(String nome) {
		return false;
	}

	public boolean cadastraNovoVet(String nome, String crmv, String endereco, String tel) {
		return false;
	}

}
