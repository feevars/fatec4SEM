package controllers;

import entities.Pet;

public class ConsultaControl {

	public void realizar() {

	}

	public boolean atualizarStatus() {
		return false;
	}

}
