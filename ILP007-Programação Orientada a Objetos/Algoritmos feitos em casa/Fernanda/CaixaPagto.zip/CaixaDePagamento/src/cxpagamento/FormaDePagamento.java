package cxpagamento;

public abstract class FormaDePagamento {
	public abstract String imprimePagamento(Double valor);
}
