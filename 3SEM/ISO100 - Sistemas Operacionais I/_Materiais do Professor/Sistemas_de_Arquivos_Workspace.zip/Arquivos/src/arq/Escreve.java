package arq;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;

public class Escreve {

	public File geraArquivo(){
		File arquivo = null;
		String diretorioBase = System.getProperty("user.home") + 
			"/Desktop";
		File dir = new File(diretorioBase);
		
		JFileChooser chooser = new JFileChooser();
		chooser.setCurrentDirectory(dir);
		chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
		
		FileNameExtensionFilter filtro = new
			FileNameExtensionFilter("Arquivos Texto (.txt)", "txt");
		
		chooser.setAcceptAllFileFilterUsed(false);
		chooser.addChoosableFileFilter(filtro);
		
		int retorno = chooser.showSaveDialog(null);
		
		if (retorno == JFileChooser.APPROVE_OPTION){
			String nomeArquivo = 
				chooser.getSelectedFile().getAbsolutePath()+".txt";
			arquivo = new File(nomeArquivo);
		}
		
		return arquivo;
	}
	
	public String geraTexto(){
		String linha = "";
		String texto = "";
		StringBuffer buffer = new StringBuffer();
		
		while (!linha.equals("fim")){
			linha = 
				JOptionPane.showInputDialog(null, 
						"Digite uma linha do texto",
						"Cria��o do Texto",
						JOptionPane.QUESTION_MESSAGE);
			if (!linha.equals("fim")){
				buffer.append(linha);
				buffer.append("\r\n");
			}
		}
		texto = buffer.toString();
		return texto;
	}
	
	public void preencheArquivo(File arquivo, String texto){
		try {
			FileWriter abreArquivo = new FileWriter(arquivo);
			PrintWriter escreveArquivo = 
				new PrintWriter(abreArquivo);
			escreveArquivo.write(texto);
			escreveArquivo.flush();
			escreveArquivo.close();
			abreArquivo.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
}





