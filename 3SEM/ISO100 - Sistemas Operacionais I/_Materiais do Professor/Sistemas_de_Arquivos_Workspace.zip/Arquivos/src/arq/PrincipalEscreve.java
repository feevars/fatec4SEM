package arq;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;

public class PrincipalEscreve {

	public static void main(String[] args) {

		Escreve escreve = new Escreve();
		File arquivo = escreve.geraArquivo();
		if (arquivo != null){
			String texto = escreve.geraTexto();
			escreve.preencheArquivo(arquivo, texto);
			Desktop desktop = Desktop.getDesktop();
			try {
				desktop.print(arquivo);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
	}
}
