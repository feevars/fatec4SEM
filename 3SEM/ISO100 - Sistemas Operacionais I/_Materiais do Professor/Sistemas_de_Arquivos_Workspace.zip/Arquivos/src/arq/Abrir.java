package arq;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;

import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;

import com.sun.corba.se.spi.orbutil.fsm.InputImpl;

public class Abrir {

	public File geraArquivo(){
		File arquivo = null;
		String diretorioBase = System.getProperty("user.home") + 
			"/Desktop";
		File dir = new File(diretorioBase);
		
		JFileChooser chooser = new JFileChooser();
		chooser.setCurrentDirectory(dir);
		chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
		
		FileNameExtensionFilter filtro = new
			FileNameExtensionFilter("Arquivos Texto (.txt)", "txt");
		
		chooser.setAcceptAllFileFilterUsed(false);
		chooser.addChoosableFileFilter(filtro);
		
		int retorno = chooser.showOpenDialog(null);
		
		if (retorno == JFileChooser.APPROVE_OPTION){
			String nomeArquivo = 
				chooser.getSelectedFile().getAbsolutePath();
			arquivo = new File(nomeArquivo);
		}
		
		return arquivo;
	}
	
	public void escreveConteudoArquivo(File arquivo){
		try {
			FileInputStream abreArquivo = 
				new FileInputStream(arquivo);
			InputStreamReader leFluxo = 
				new InputStreamReader(abreArquivo);
			BufferedReader buffer = new BufferedReader(leFluxo);
			String linha = buffer.readLine();
			while (linha != null){
				System.out.println(linha);
				linha = buffer.readLine();
			}
			buffer.close();
			leFluxo.close();
			abreArquivo.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
	
	
}


