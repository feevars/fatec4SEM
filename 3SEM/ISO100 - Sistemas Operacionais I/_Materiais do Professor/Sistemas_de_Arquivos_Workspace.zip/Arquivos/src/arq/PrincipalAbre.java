package arq;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;

public class PrincipalAbre {

	public static void main(String[] args) {
		
		Abrir abrir = new Abrir();
		File arquivo = abrir.geraArquivo();
		if (arquivo != null){
			abrir.escreveConteudoArquivo(arquivo);
			Desktop desktop = Desktop.getDesktop();
			try {
				desktop.open(arquivo);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
	}

}
