package fatec.zl.jokenpo;

import android.support.v7.app.ActionBarActivity;
import android.support.v7.app.ActionBar;
import android.support.v4.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.RadioButton;
import android.widget.Toast;
import android.os.Build;

public class TelaPrincipal extends ActionBarActivity {

	RadioButton rbPedra, rbPapel, rbTesoura;
	String selecao;
	Bundle parametrosSaida;
	Intent chamaTelaResultado;
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_tela_principal);

		if (savedInstanceState == null) {
			getSupportFragmentManager().beginTransaction()
					.add(R.id.container, new PlaceholderFragment()).commit();
		}
		
		rbPedra = (RadioButton) findViewById(R.id.rbPedra);
		rbPapel = (RadioButton) findViewById(R.id.rbPapel);
		rbTesoura = (RadioButton) findViewById(R.id.rbTesoura);
		
		OnClickListener pedra = new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				selecao = (String) rbPedra.getText();
				joga(selecao);
			}
		};
		
		OnClickListener papel = new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				selecao = (String) rbPapel.getText();
				joga(selecao);
			}
		};
		
		OnClickListener tesoura = new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				selecao = (String) rbTesoura.getText();
				joga(selecao);
			}
		};
		
		rbPedra.setOnClickListener(pedra);
		rbPapel.setOnClickListener(papel);
		rbTesoura.setOnClickListener(tesoura);
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {

		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.tela_principal, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {

		switch(item.getItemId()){
		case R.id.sairPrincipal:
			encerra();
			return true;
		}
		
		return super.onOptionsItemSelected(item);
	}

	/**
	 * A placeholder fragment containing a simple view.
	 */
	public static class PlaceholderFragment extends Fragment {

		public PlaceholderFragment() {
		}

		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container,
				Bundle savedInstanceState) {
			View rootView = inflater.inflate(R.layout.fragment_tela_principal,
					container, false);
			return rootView;
		}
	}
	
	public void joga(String opcao){
		parametrosSaida = new Bundle();
		parametrosSaida.putString("opcao", opcao);
		chamaTelaResultado = new Intent(TelaPrincipal.this,
								TelaResultado.class);
		chamaTelaResultado.putExtras(parametrosSaida);
		TelaPrincipal.this.startActivity(chamaTelaResultado);
		TelaPrincipal.this.finish();
	}
	
	public void encerra(){
		TelaPrincipal.this.finish();
	}

}








