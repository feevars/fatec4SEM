/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author FSilva
 */
public class NO {
	public int dado;
	public NO prox;

	public NO(int e){
		dado=e;
		prox=null;
	}
}
