package view;

import java.util.EventListener;

public interface ListenerFormDisciplina extends EventListener {
	public void FormEventOcurred(EventoFormDisciplina e);
}
