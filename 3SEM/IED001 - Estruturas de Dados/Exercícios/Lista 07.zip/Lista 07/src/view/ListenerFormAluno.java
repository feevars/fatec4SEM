package view;

import java.util.EventListener;

public interface ListenerFormAluno extends EventListener {
	public void FormEventOcurred(EventoFormAluno e);
}
