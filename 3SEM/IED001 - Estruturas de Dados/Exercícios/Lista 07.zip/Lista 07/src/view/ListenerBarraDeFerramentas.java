package view;

import java.util.EventListener;

public interface ListenerBarraDeFerramentas extends EventListener {
	public void FormEventOcurred(EventoBarraDeFerramentas e);
}
