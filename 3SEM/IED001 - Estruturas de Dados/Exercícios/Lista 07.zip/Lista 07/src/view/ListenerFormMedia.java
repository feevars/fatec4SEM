package view;

public interface ListenerFormMedia {
	public void FormEventOcurred(EventoFormMedia e);
}
