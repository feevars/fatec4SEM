
public class Lista {                  
	private double temperaturas[];                  
	private int tamanho;                 

	public Lista(){                       
		temperaturas=new double [100];                    
		tamanho=0;                            
	}

	public void AdicionaFinal(double temperatura){     

		if (tamanho<temperaturas.length){
			temperaturas[tamanho]=temperatura;                     
			tamanho++;                            
		}
		else{
			System.out.println("Lista Cheia");    
		}
	}

	public void AdicionaInicio(double e){   
		if (tamanho<temperaturas.length){           
			for (int i=tamanho;i>0;i--){         
				temperaturas[i]=temperaturas[i-1];                 
			}
			temperaturas[0]=e;                          
			tamanho++;                           
		}
		else{
			System.out.println("Erro, lista cheia");        
		}
	}

	public void  AdicionaQualquerPosicao(double e, int pos){
		int i;
		if ((tamanho<temperaturas.length)&&(pos<tamanho+1)&&(pos>=0)){


			for (i=tamanho;i!=pos;i--){                     
				if (i!=0){                                      
					temperaturas[i]=temperaturas[i-1];                            
				}
			}
			temperaturas[i]=e;                                     
			tamanho++;                                      
		}
	}

	public double RemoveFinal(){
		double retorno = 0;
		int i;
		if (tamanho>=1){                               
			retorno=temperaturas[tamanho-1];
			for (i=0;i<tamanho;i++){                       
				if (i==tamanho-1)                             
					tamanho--;                                    
			}
		}
		return retorno;
	}

	public double RemoveInicio(){
		double retorno = 0;
		int i;
		if (tamanho>=1){                              
			retorno=temperaturas[0];
			for (i=1;i<tamanho;i++){                      
				temperaturas[i-1]=temperaturas[i];                          
			}
			tamanho--;                                   
		}
		return retorno;
	}

	public double RemoveQualquerPosicao(int pos){
		int i = 0;
		double retorno=0;                                         

		if ((pos<tamanho)&&(pos>=0)&&(tamanho>=1)){
			retorno=temperaturas[pos];

			for (i=pos;i<tamanho-1;i++){                 
				temperaturas[i]=temperaturas[i+1];                         
			}

			tamanho--;                                   
		}
		return retorno;
	}



	public String percorre(){                    
		String aux=" ";

		for (int i=0;i<tamanho;i++){
			aux=aux+"\n"+temperaturas[i];
		}
		return aux;
	}
}

